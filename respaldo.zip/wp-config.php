<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'prettypr_princes');

/** MySQL database username */
define('DB_USER', 'prettypr_admin');

/** MySQL database password */
define('DB_PASSWORD', 'alpimaasociados');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'ARN ?kC}{nOYH`Qs%HuVN#z)dg&7?6D5G(s=@p~2q@|rqaZL(*h&NwE^7@^wi#)m');
define('SECURE_AUTH_KEY',  '`GfdSZ*B3#J #~A=saLJHvCC9C5WPjGotmlvX#O]w~-.y$T,Qkfx<62p<wPUo4P+');
define('LOGGED_IN_KEY',    ',^+#a+#llSIo#y%M;zs[|.:B>ZwQb(h5DvSFVv9C]U;EAUR&I)K(;W%e](~ECF&+');
define('NONCE_KEY',        'V;;CLX$lZ+3#au$w1csYN/@oz@C}Z[:J^apk;jrX/R~Pxh[(f2,B|X!$}80i~Q#g');
define('AUTH_SALT',        's~SnvFH*1=Sy4JLh~L<}k@iDcFg6Y)9N_<YjiXuM;%z3`ON,*E-EjJA&kt8?nt$#');
define('SECURE_AUTH_SALT', 'Mv<t)x[yva&$>3-8s|$d9i0#e{`<-(48M#r9RL{#?zs7g-%>g}x{,v<uDHotQ==N');
define('LOGGED_IN_SALT',   'w`X{^GKYvVbry*/$bIY&?f;4q`S G2$S9YRGhU^A{#0/P$J.[r[*iL&UxxqBL2<w');
define('NONCE_SALT',       'c?1_7sVwLqlF0h:l#WQqCChT}s3z(0,yEjpm_$Br +,X[|{l{6[#,v?My==[(V3?');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
